<?php
function MakeConnection(){
    $servername="localhost";
    $username="root";
    $password="";
    $database="game p3";

try{
    $pdo = new PDO("mysql:host=" . $servername .";dbname=" . $database, $username, $password);

     $pdo -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e)
{
    die("ERROR: Verbinding mislukt" .$e->getMessage());

}
return $pdo;
}

function selectAll()
{
    $con=MakeConnection();
    $query="SELECT * FROM user";
    $stmt =$con->prepare($query);
    try{
        $stmt->execute();
        $result =$stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }catch(PDOException $e){echo 'Exception because '.$e;}
    
}
function insertUser($username,$email,$password)
{
   $con=MakeConnection();
    $query="INSERT INTO user(username, email, password) VALUES (:username,:email, :password)";
    $stmt =$con->prepare($query);
    try{
        $stmt->execute(array(':username'=>$username,':email'=>$email, ':password'=>$password));
    }
    catch(PDOException $e){echo 'Exception because '.$e;} 
            
}

?>