<?php
require_once "MYDB.php";
if(isset($_POST["submit"])) {
    insertUser($_POST["username"],$_POST["email"],$_POST["password"]);
}




?>