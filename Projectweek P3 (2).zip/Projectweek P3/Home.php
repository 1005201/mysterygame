<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      .button {
        background-color:green;
        border:none;
      }
      p {
        size:100px;
        color:white;
        text-align:center;
      }
      body {
        background-image: url('pond_zonder_water.png');
      }
    </style>
</head>
<body>
  <br><br><br><br>
  <form name="myform" action="" method="POST">
  <input onclick = "hideButton(this)" type="submit" value="Option A" name="optionA">
  <input onclick = "hideButton(this)" type="submit" value="Option B" name="optionB">
    </form>
<script>
function hideButton(x) {
disappear = x.style.display = 'none';

}
</script>

<?php 
   if (isset($_POST["optionA"]))
   {
      $storyA1 = "<p style = 'margin:0px 200px;'>EINDHOVEN - Een 52-jarige man uit Eindhoven is maandag tijdens een ‘bezorgronde’ aangehouden op verdenking van het handelen in verdovende middelen. Volgens de politie werd in zijn woning een aanzienlijke hoeveelheid drugs aangetroffen, waaronder een partij amfetamine.</p>";
       echo $storyA1;
       $storybutton = "<br><form name='myform' method='POST'><input style = 'margin:0px 200px;' type ='submit' value = 'Continue' name = 'continue'></form>";
       echo $storybutton;
       }
       if (isset($_POST['continue'])){
        $story2 = "<p style = 'text-align:center;'>Crabby</p>";
        echo $story2;
       }
if (isset($_POST["optionB"])){
    $storyB1 = "<p style = 'margin:0px 200px;'>One more drink she said
    I think I'm losing my head now.
    Tonight we'll make bad memories.</p>";
    echo $storyB1;
    $continue = "<br><form name='myform' method='POST'><input style = 'margin:0px 350px;' type ='submit' value = 'Continue' name = 'continueB1'></form>";
    echo $continue;
}
if (isset($_POST['continueB1'])){
    $storyB2 = "<img src Orange Justice</p>";
    echo $storyB2;
}
?>

</body>
</html>