<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<style>
body {
    background-color:black;
}
    </style>
<body>
    <?php
require_once "MYDB.php";
    ?>
    <img style = "margin:0px 575px;" width = "80px;" src = "https://logodownload.org/wp-content/uploads/2020/10/epic-games-logo.png">
    <h1 style = "text-align:center;color:white;">Register</h1><br><br>

<div class = "input">
<form action = "actionUser.php" method = "post">
    <p style = "text-align:center;color:white;">Choose your username:</p><br>
    <input  style = "display:block;margin-right:auto;margin-left:auto;" type = "text"
    name = "username"><br>
<p style = "text-align:center;color:white;">Your email:</p><br>
    <input style = "display:block;margin-right:auto;margin-left:auto;" type = "text" name = "email"><br>
<p style = "text-align:center;color:white;">Your password:</p><br>
    <input  style = "display:block;margin-right:auto;margin-left:auto;" type = "text" name = "password"><br><br>
    <input  style = "display:block;margin-right:auto;margin-left:auto;border:none;background-color:aqua;padding:20px 20px;font-weight:bold;" type = "submit" name = "submit" value = "Create my account">
</form><br>
</div>
<script>


</script>
</body>
</html>